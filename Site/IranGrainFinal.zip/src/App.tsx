import { useEffect, useState } from "react";
import { useReveal } from "./hooks/useReveal";
import CustomCursor from "./components/CustomCursor";
import Navbar from "./components/Navbar";
import Hero from "./components/Hero";
import Stats from "./components/Stats";
import About from "./components/About";
import Services from "./components/Services";
import Prices from "./components/Prices";
import Events from "./components/Events";
import Members from "./components/Members";
import Contact from "./components/Contact";
import Footer from "./components/Footer";

export default function App() {
  useReveal();
  const [showTop, setShowTop] = useState(false);

  useEffect(() => {
    const onScroll = () => setShowTop(window.scrollY > 600);
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  return (
    <div className="min-h-screen bg-cream">
      <Navbar />
      <main>
        <Hero />
        <Stats />
        <About />
        <Services />
        <Prices />
        <Events />
        <Members />
        <Contact />
      </main>
      <Footer />

      {/* Back to top */}
      <button
        onClick={() => window.scrollTo({ top: 0, behavior: "smooth" })}
        aria-label="بازگشت به بالا"
        className={`fixed bottom-6 left-6 z-40 grid h-12 w-12 place-items-center rounded-full bg-grain-800 text-xl text-white shadow-xl shadow-grain-900/30 transition-all duration-300 hover:bg-grain-900 ${
          showTop
            ? "translate-y-0 opacity-100"
            : "pointer-events-none translate-y-4 opacity-0"
        }`}
      >
        ↑
      </button>

      <CustomCursor />
    </div>
  );
}
