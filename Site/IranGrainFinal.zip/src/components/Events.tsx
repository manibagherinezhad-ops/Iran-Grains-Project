const EVENTS = [
  {
    date: { day: "۱۸", month: "مرداد" },
    cat: "ایران گرین",
    catColor: "bg-gold-400/20 text-gold-200",
    title: "نمایشگاه تخصصی ایران گرین ۱۴۰۳",
    excerpt:
      "بزرگ‌ترین گردهمایی صنعت غلات و دانه‌های روغنی با حضور تولیدکنندگان، واردکنندگان و صنایع تبدیلی.",
  },
  {
    date: { day: "۰۲", month: "شهریور" },
    cat: "جلسات تخصصی",
    catColor: "bg-grain-400/25 text-grain-200",
    title: "نشست بررسی بخشنامه‌های جدید واردات",
    excerpt:
      "بررسی آخرین تغییرات مقررات گمرکی و تسهیلات وارداتی غلات با حضور کارشناسان ذی‌ربط.",
  },
  {
    date: { day: "۱۵", month: "شهریور" },
    cat: "کارگاه آموزشی",
    catColor: "bg-white/15 text-white",
    title: "کارگاه کنترل کیفیت و استاندارد سیلوها",
    excerpt:
      "آموزش اصول انبارداری، کنترل آفات و انطباق با استانداردهای ملی برای مدیران فنی سیلوها.",
  },
];

export default function Events() {
  return (
    <section id="events" className="relative overflow-hidden py-24 sm:py-28">
      {/* subtle bg */}
      <div className="absolute inset-0 bg-gradient-to-b from-cream to-grain-50" />
      <div className="relative mx-auto max-w-7xl px-4 sm:px-6">
        <div className="flex flex-col items-start justify-between gap-6 sm:flex-row sm:items-end">
          <div className="max-w-xl">
            <span
              data-animate
              className="inline-flex items-center gap-2 rounded-full bg-white px-4 py-1.5 text-sm font-medium text-grain-700 shadow-sm"
            >
              رویدادها و اخبار
            </span>
            <h2
              data-animate
              data-animate-delay="0.05s"
              className="mt-4 text-3xl font-black text-grain-950 sm:text-4xl"
            >
              تازه‌های انجمن و صنعت غلات
            </h2>
          </div>
          <a
            href="#contact"
            data-animate
            className="inline-flex items-center gap-1 text-sm font-bold text-grain-700 hover:text-gold-600"
          >
            مشاهده‌ی همه‌ی رویدادها <span>←</span>
          </a>
        </div>

        <div className="mt-14 grid gap-6 lg:grid-cols-3">
          {EVENTS.map((e, i) => (
            <article
              key={e.title}
              data-animate
              data-animate-delay={`${i * 0.1}s`}
              className="group flex flex-col overflow-hidden rounded-3xl bg-white shadow-sm ring-1 ring-grain-900/5 transition-all duration-300 hover:-translate-y-1.5 hover:shadow-xl hover:shadow-grain-900/10"
            >
              {/* visual header */}
              <div className="relative h-40 overflow-hidden bg-gradient-to-br from-grain-700 to-grain-900">
                <div className="absolute inset-0 opacity-20 [background-image:radial-gradient(circle_at_20%_20%,white_2px,transparent_2px)] [background-size:24px_24px]" />
                <div className="absolute right-5 top-5 text-center rounded-2xl bg-white/95 px-4 py-2 shadow-lg">
                  <div className="text-xl font-black text-grain-900">
                    {e.date.day}
                  </div>
                  <div className="text-[11px] font-medium text-grain-600">
                    {e.date.month}
                  </div>
                </div>
                <span
                  className={`absolute bottom-5 right-5 rounded-full px-3 py-1 text-xs font-bold ${e.catColor}`}
                >
                  {e.cat}
                </span>
                <span className="absolute bottom-5 left-5 text-5xl opacity-30 transition-transform duration-500 group-hover:scale-125">
                  🌾
                </span>
              </div>

              <div className="flex flex-1 flex-col p-6">
                <h3 className="text-lg font-bold text-grain-950">{e.title}</h3>
                <p className="mt-2 flex-1 text-sm leading-7 text-grain-600">
                  {e.excerpt}
                </p>
                <a
                  href="#contact"
                  className="mt-4 inline-flex items-center gap-1 text-sm font-bold text-grain-700 transition-colors group-hover:text-gold-600"
                >
                  جزئیات و ثبت‌نام <span>←</span>
                </a>
              </div>
            </article>
          ))}
        </div>
      </div>
    </section>
  );
}
