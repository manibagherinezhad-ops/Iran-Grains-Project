import { useEffect, useRef, useState } from "react";

const STATS = [
  { value: 22, suffix: "+", label: "سال تجربه‌ی تخصصی" },
  { value: 320, suffix: "+", label: "شرکت و نهاد عضو" },
  { value: 14, suffix: "", label: "کمیته‌ی علمی و فنی" },
  { value: 50, suffix: "+", label: "رویداد و همایش سالانه" },
];

const toFa = (n: number) => n.toLocaleString("fa-IR");

function useCountUp(target: number, run: boolean, duration = 1600) {
  const [val, setVal] = useState(0);
  useEffect(() => {
    if (!run) return;
    let raf = 0;
    const start = performance.now();
    const tick = (now: number) => {
      const p = Math.min((now - start) / duration, 1);
      const eased = 1 - Math.pow(1 - p, 3);
      setVal(Math.round(target * eased));
      if (p < 1) raf = requestAnimationFrame(tick);
    };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, [target, run, duration]);
  return val;
}

function StatItem({
  value,
  suffix,
  label,
  run,
}: {
  value: number;
  suffix: string;
  label: string;
  run: boolean;
}) {
  const val = useCountUp(value, run);
  return (
    <div className="text-center">
      <div className="text-4xl font-black text-gold-400 sm:text-5xl">
        {toFa(val)}
        <span className="text-gold-300">{suffix}</span>
      </div>
      <div className="mt-2 text-sm text-white/70">{label}</div>
    </div>
  );
}

export default function Stats() {
  const ref = useRef<HTMLDivElement>(null);
  const [run, setRun] = useState(false);

  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const io = new IntersectionObserver(
      ([e]) => {
        if (e.isIntersecting) {
          setRun(true);
          io.disconnect();
        }
      },
      { threshold: 0.3 }
    );
    io.observe(el);
    return () => io.disconnect();
  }, []);

  return (
    <section id="stats" ref={ref} className="bg-grain-900 py-16 text-white">
      <div className="mx-auto grid max-w-7xl grid-cols-2 gap-8 px-4 sm:px-6 lg:grid-cols-4">
        {STATS.map((s) => (
          <StatItem key={s.label} {...s} run={run} />
        ))}
      </div>
    </section>
  );
}
