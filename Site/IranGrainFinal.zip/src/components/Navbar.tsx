import { useEffect, useState } from "react";

type NavItem = {
  label: string;
  href: string;
  children?: { label: string; href: string }[];
};

const NAV: NavItem[] = [
  { label: "خانه", href: "#home" },
  {
    label: "درباره ما",
    href: "#about",
    children: [
      { label: "آشنایی با انجمن", href: "#about" },
      { label: "اساسنامه", href: "#about" },
      { label: "اعضای هیأت مدیره", href: "#about" },
    ],
  },
  {
    label: "رویدادها",
    href: "#events",
    children: [
      { label: "جلسات تخصصی", href: "#events" },
      { label: "ایران گرین", href: "#events" },
    ],
  },
  { label: "بخشنامه‌ها", href: "#services" },
  { label: "قیمت‌های مصوب", href: "#prices" },
  {
    label: "اعضا",
    href: "#members",
    children: [
      { label: "شرکت‌های عضو", href: "#members" },
      { label: "شرایط عضویت", href: "#members" },
    ],
  },
  { label: "تماس با ما", href: "#contact" },
];

export default function Navbar() {
  const [scrolled, setScrolled] = useState(false);
  const [open, setOpen] = useState(false);
  const [active, setActive] = useState("#home");

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 30);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  useEffect(() => {
    const ids = [
      "home",
      "about",
      "events",
      "services",
      "prices",
      "members",
      "contact",
    ];
    const sections = ids
      .map((id) => document.getElementById(id))
      .filter(Boolean) as HTMLElement[];

    const io = new IntersectionObserver(
      (entries) => {
        entries.forEach((e) => {
          if (e.isIntersecting) setActive("#" + e.target.id);
        });
      },
      { rootMargin: "-45% 0px -50% 0px" }
    );
    sections.forEach((s) => io.observe(s));
    return () => io.disconnect();
  }, []);

  useEffect(() => {
    document.body.style.overflow = open ? "hidden" : "";
    return () => {
      document.body.style.overflow = "";
    };
  }, [open]);

  return (
    <header
      className={`fixed inset-x-0 top-0 z-50 transition-all duration-300 ${
        scrolled
          ? "bg-cream/90 py-2 shadow-[0_8px_30px_rgba(15,31,14,0.08)] backdrop-blur-md"
          : "bg-transparent py-4"
      }`}
    >
      <div className="mx-auto flex max-w-7xl items-center justify-between gap-4 px-4 sm:px-6">
        {/* Logo */}
        <a href="#home" className="flex shrink-0 items-center gap-2">
          <span className="grid h-11 w-11 place-items-center rounded-2xl bg-gradient-to-br from-grain-600 to-grain-800 text-2xl shadow-lg shadow-grain-900/20">
            🌾
          </span>
          <span className="leading-tight">
            <span
              className={`block text-lg font-extrabold ${
                scrolled ? "text-grain-900" : "text-white"
              }`}
            >
              انجمن غلات ایران
            </span>
            <span
              className={`block text-[11px] ${
                scrolled ? "text-grain-600" : "text-gold-200"
              }`}
            >
              مرجع تخصصی صنعت غلات
            </span>
          </span>
        </a>

        {/* Desktop nav */}
        <nav className="hidden items-center gap-1 lg:flex">
          {NAV.map((item) => (
            <div key={item.label} className="group relative">
              <a
                href={item.href}
                className={`flex items-center gap-1 rounded-full px-3 py-2 text-sm font-medium transition-colors ${
                  active === item.href
                    ? scrolled
                      ? "text-gold-600"
                      : "text-gold-300"
                    : scrolled
                    ? "text-grain-800 hover:text-gold-600"
                    : "text-white/90 hover:text-gold-300"
                }`}
              >
                {item.label}
                {item.children && (
                  <span className="mt-0.5 text-[10px]">▾</span>
                )}
              </a>
              {item.children && (
                <div className="invisible absolute right-0 top-full translate-y-2 pt-3 opacity-0 transition-all duration-200 group-hover:visible group-hover:translate-y-0 group-hover:opacity-100 group-focus-within:visible group-focus-within:opacity-100">
                  <ul className="min-w-52 rounded-2xl bg-white p-2 shadow-xl shadow-grain-900/10 ring-1 ring-grain-900/5">
                    {item.children.map((c) => (
                      <li key={c.label}>
                        <a
                          href={c.href}
                          className="block rounded-xl px-4 py-2.5 text-sm text-grain-700 transition-colors hover:bg-grain-50 hover:text-gold-600"
                        >
                          {c.label}
                        </a>
                      </li>
                    ))}
                  </ul>
                </div>
              )}
            </div>
          ))}
        </nav>

        {/* Actions */}
        <div className="flex items-center gap-3">
          <a
            href="#contact"
            className="hidden rounded-full bg-gold-400 px-5 py-2.5 text-sm font-bold text-grain-950 shadow-lg shadow-gold-500/20 transition-colors hover:bg-gold-500 sm:inline-flex"
          >
            درخواست عضویت
          </a>
          <button
            onClick={() => setOpen((o) => !o)}
            aria-label="باز و بسته کردن منو"
            aria-expanded={open}
            className={`grid h-11 w-11 place-items-center rounded-xl lg:hidden ${
              scrolled
                ? "bg-grain-900/5 text-grain-900"
                : "bg-white/15 text-white"
            }`}
          >
            <div className="space-y-1.5">
              <span
                className={`block h-0.5 w-5 bg-current transition-transform ${
                  open ? "translate-y-2 rotate-45" : ""
                }`}
              />
              <span
                className={`block h-0.5 w-5 bg-current transition-opacity ${
                  open ? "opacity-0" : ""
                }`}
              />
              <span
                className={`block h-0.5 w-5 bg-current transition-transform ${
                  open ? "-translate-y-2 -rotate-45" : ""
                }`}
              />
            </div>
          </button>
        </div>
      </div>

      {/* Mobile menu */}
      <div
        className={`overflow-hidden transition-all duration-300 lg:hidden ${
          open ? "max-h-[85vh] opacity-100" : "max-h-0 opacity-0"
        }`}
      >
        <nav className="mx-4 mt-3 space-y-1 rounded-3xl bg-white p-4 shadow-2xl">
          {NAV.map((item) => (
            <div key={item.label}>
              <a
                href={item.href}
                onClick={() => setOpen(false)}
                className="block rounded-2xl px-4 py-3 font-medium text-grain-800 hover:bg-grain-50"
              >
                {item.label}
              </a>
              {item.children && (
                <div className="space-y-1 pb-2 pe-4">
                  {item.children.map((c) => (
                    <a
                      key={c.label}
                      href={c.href}
                      onClick={() => setOpen(false)}
                      className="block rounded-xl px-4 py-2 text-sm text-grain-600 hover:bg-grain-50"
                    >
                      — {c.label}
                    </a>
                  ))}
                </div>
              )}
            </div>
          ))}
          <a
            href="#contact"
            onClick={() => setOpen(false)}
            className="mt-2 block rounded-2xl bg-gold-400 px-4 py-3 text-center font-bold text-grain-950"
          >
            درخواست عضویت
          </a>
        </nav>
      </div>
    </header>
  );
}
