const COMPANIES = [
  "شرکت آرد ایران",
  "گروه نوسا",
  "سیلوهای مرکزی",
  "کشت‌وصنعت مگسر",
  "بازرگانی پارس غلات",
  "صنایع غذایی کوروش",
  "گروه صنعتی آریا",
  "تجارت غلات سپهر",
];

const BENEFITS = [
  "دریافت رایگان بخشنامه‌ها و قیمنت‌های مصوب",
  "شرکت رایگان در همایش‌ها و کارگاه‌ها",
  "مشاوره‌ی حقوقی و فنی تخصصی",
  "معرفی در فهرست رسمی اعضای انجمن",
];

export default function Members() {
  return (
    <section id="members" className="overflow-hidden py-24 sm:py-28">
      <div className="mx-auto max-w-7xl px-4 sm:px-6">
        <div className="mx-auto max-w-2xl text-center">
          <span
            data-animate
            className="inline-flex items-center gap-2 rounded-full bg-grain-100 px-4 py-1.5 text-sm font-medium text-grain-700"
          >
            اعضای انجمن
          </span>
          <h2
            data-animate
            data-animate-delay="0.05s"
            className="mt-4 text-3xl font-black text-grain-950 sm:text-4xl"
          >
            به خانواده‌ی بزرگ غلات ایران بپیوندید
          </h2>
          <p
            data-animate
            data-animate-delay="0.1s"
            className="mt-4 leading-8 text-grain-600"
          >
            صدها شرکت و نهاد معتبر از سراسر کشور، عضو انجمن غلات ایران هستند.
          </p>
        </div>
      </div>

      {/* Marquee */}
      <div
        data-animate
        className="relative mt-12 [mask-image:linear-gradient(to_right,transparent,black_8%,black_92%,transparent)]"
      >
        <div className="flex w-max animate-marquee gap-4">
          {[...COMPANIES, ...COMPANIES].map((c, i) => (
            <div
              key={c + i}
              className="flex items-center gap-2 whitespace-nowrap rounded-2xl bg-white px-6 py-4 text-sm font-bold text-grain-800 shadow-sm ring-1 ring-grain-900/5"
            >
              <span className="text-lg">🏭</span> {c}
            </div>
          ))}
        </div>
      </div>

      {/* Membership CTA */}
      <div className="mx-auto mt-16 max-w-7xl px-4 sm:px-6">
        <div
          data-animate
          className="relative overflow-hidden rounded-[2.5rem] bg-gradient-to-l from-grain-800 to-grain-950 p-8 text-white sm:p-12"
        >
          <div className="absolute -left-16 -top-16 h-64 w-64 rounded-full bg-gold-400/15 blur-3xl" />
          <div className="relative grid items-center gap-8 lg:grid-cols-2">
            <div>
              <h3 className="text-2xl font-black sm:text-3xl">
                شرایط و مزایای عضویت
              </h3>
              <p className="mt-3 leading-8 text-white/70">
                عضویت در انجمن، دسترسی شما را به شبکه‌ای از فرصت‌ها، اطلاعات و
                حمایت‌های تخصصی ممکن می‌سازد.
              </p>
              <a
                href="#contact"
                className="mt-6 inline-flex items-center gap-2 rounded-full bg-gold-400 px-7 py-3.5 font-bold text-grain-950 transition-colors hover:bg-gold-300"
              >
                ثبت درخواست عضویت <span>←</span>
              </a>
            </div>
            <ul className="grid gap-3 sm:grid-cols-2">
              {BENEFITS.map((b) => (
                <li
                  key={b}
                  className="flex items-start gap-3 rounded-2xl bg-white/5 p-4 ring-1 ring-white/10"
                >
                  <span className="mt-0.5 grid h-6 w-6 shrink-0 place-items-center rounded-full bg-gold-400 text-xs text-grain-950">
                    ✓
                  </span>
                  <span className="text-sm text-white/85">{b}</span>
                </li>
              ))}
            </ul>
          </div>
        </div>
      </div>
    </section>
  );
}
