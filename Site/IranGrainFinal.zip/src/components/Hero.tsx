import heroImg from "../../public/images/hero-wheat.jpg";

export default function Hero() {
  return (
    <section
      id="home"
      className="relative flex min-h-screen items-center overflow-hidden"
    >
      {/* Background */}
      <div className="absolute inset-0">
        <img
          src={heroImg}
          alt="مزرعه گندم طلایی"
          className="h-full w-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-l from-grain-950/90 via-grain-900/70 to-grain-900/40" />
        <div className="absolute inset-0 bg-gradient-to-t from-grain-950 via-transparent to-grain-950/30" />
      </div>

      {/* Decorative glow */}
      <div className="absolute -left-20 -top-20 h-72 w-72 rounded-full bg-gold-400/20 blur-3xl" />
      <div className="absolute bottom-0 right-1/4 h-72 w-72 rounded-full bg-grain-400/20 blur-3xl" />

      <div className="relative mx-auto w-full max-w-7xl px-4 py-32 sm:px-6">
        <div className="max-w-2xl">
          <span
            data-animate
            className="inline-flex items-center gap-2 rounded-full bg-white/10 px-4 py-2 text-sm text-gold-200 ring-1 ring-white/20 backdrop-blur"
          >
            🌱 مرجع تخصصی صنعت غلات ایران
          </span>
          <h1
            data-animate
            data-animate-delay="0.1s"
            className="mt-6 text-4xl font-black leading-[1.15] text-white sm:text-6xl"
          >
            آینده‌ی <span className="text-gold-400">غلات</span> را
            <br /> با هم می‌سازیم
          </h1>
          <p
            data-animate
            data-animate-delay="0.2s"
            className="mt-6 max-w-xl text-lg leading-8 text-white/80"
          >
            انجمن غلات ایران با بیش از دو دهه تجربه، پل ارتباطی میان
            تولیدکنندگان، واردکنندگان و نهادهای دولتی برای توسعه‌ی پایدار صنعت
            غلات و تأمین امنیت غذایی کشور است.
          </p>
          <div
            data-animate
            data-animate-delay="0.3s"
            className="mt-9 flex flex-wrap gap-4"
          >
            <a
              href="#about"
              className="inline-flex items-center gap-2 rounded-full bg-gold-400 px-7 py-3.5 font-bold text-grain-950 transition-all hover:bg-gold-300 hover:shadow-2xl hover:shadow-gold-500/30"
            >
              درباره انجمن <span>←</span>
            </a>
            <a
              href="#contact"
              className="inline-flex items-center rounded-full bg-white/10 px-7 py-3.5 font-bold text-white ring-1 ring-white/30 backdrop-blur transition-all hover:bg-white/20"
            >
              درخواست عضویت
            </a>
          </div>
        </div>
      </div>

      {/* Scroll indicator */}
      <a
        href="#stats"
        className="absolute bottom-8 left-1/2 flex -translate-x-1/2 flex-col items-center gap-2 text-xs text-white/60"
      >
        <span>اسکرول کنید</span>
        <span className="relative block h-10 w-[2px] overflow-hidden bg-white/30">
          <span className="scroll-pulse absolute inset-0 bg-gold-400" />
        </span>
      </a>
    </section>
  );
}
