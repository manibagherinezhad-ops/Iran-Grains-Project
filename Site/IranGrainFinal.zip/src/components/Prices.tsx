const ROWS = [
  { name: "گندم", moisture: "۱۳٪", price: "۸٬۲۰۰", tag: "استراتژیک" },
  { name: "جو", moisture: "۱۲٪", price: "۶٬۴۰۰", tag: "خوراک دام" },
  { name: "ذرت دامی", moisture: "۱۴٪", price: "۷٬۱۰۰", tag: "خوراک دام" },
  { name: "سویا", moisture: "۱۱٪", price: "۱۸٬۵۰۰", tag: "روغنی" },
  { name: "کلزا", moisture: "۹٪", price: "۱۶٬۲۰۰", tag: "روغنی" },
];

export default function Prices() {
  return (
    <section id="prices" className="bg-grain-900 py-24 text-white sm:py-28">
      <div className="mx-auto max-w-6xl px-4 sm:px-6">
        <div className="flex flex-col items-start justify-between gap-6 sm:flex-row sm:items-end">
          <div>
            <span
              data-animate
              className="inline-flex items-center gap-2 rounded-full bg-white/10 px-4 py-1.5 text-sm font-medium text-gold-200 ring-1 ring-white/15"
            >
              قیمت‌های مصوب
            </span>
            <h2
              data-animate
              data-animate-delay="0.05s"
              className="mt-4 text-3xl font-black sm:text-4xl"
            >
              نرخ‌های پایه‌ی خرید تضمینی
            </h2>
            <p
              data-animate
              data-animate-delay="0.1s"
              className="mt-3 max-w-xl leading-8 text-white/70"
            >
              قیمنت‌های مصوب به‌ریال/کیلوگرم اعلام می‌شود و صرفاً جهت اطلاع اعضا
              منتشر می‌گردد.
            </p>
          </div>
          <a
            href="#contact"
            data-animate
            className="inline-flex shrink-0 items-center gap-2 rounded-full bg-gold-400 px-6 py-3 font-bold text-grain-950 transition-colors hover:bg-gold-300"
          >
            <span>⬇️</span> دریافت فایل کامل
          </a>
        </div>

        {/* Table */}
        <div
          data-animate
          data-animate-delay="0.1s"
          className="mt-10 overflow-hidden rounded-3xl bg-white/5 ring-1 ring-white/10 backdrop-blur"
        >
          {/* Header */}
          <div className="hidden grid-cols-4 gap-4 border-b border-white/10 px-6 py-4 text-sm font-bold text-white/60 sm:grid">
            <div>محصول</div>
            <div>حداکثر رطوبت</div>
            <div>قیمت مصوب (ریال/کیلوگرم)</div>
            <div>دسته‌بندی</div>
          </div>

          {ROWS.map((r) => (
            <div
              key={r.name}
              className="grid grid-cols-2 gap-3 border-b border-white/5 px-6 py-4 transition-colors last:border-0 hover:bg-white/5 sm:grid-cols-4 sm:gap-4"
            >
              <div className="flex items-center gap-2 font-bold">
                <span className="grid h-8 w-8 place-items-center rounded-lg bg-gold-400/20 text-sm">
                  🌾
                </span>
                {r.name}
              </div>
              <div className="text-sm text-white/70 sm:self-center">
                <span className="text-white/40 sm:hidden">رطوبت: </span>
                {r.moisture}
              </div>
              <div className="self-center font-bold text-gold-300">
                {r.price}
              </div>
              <div className="self-center">
                <span className="rounded-full bg-grain-700 px-3 py-1 text-xs text-grain-100">
                  {r.tag}
                </span>
              </div>
            </div>
          ))}
        </div>

        <p className="mt-5 text-xs text-white/40">
          * آخرین به‌روزرسانی: ۱۴ خرداد ۱۴۰۳ — مسئولیت تغییرات احتمالی بر عهده‌ی
          مرجع صدور می‌باشد.
        </p>
      </div>
    </section>
  );
}
