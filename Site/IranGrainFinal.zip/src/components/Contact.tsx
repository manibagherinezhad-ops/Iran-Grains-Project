import type { ReactNode } from "react";
import { useState } from "react";

const INFO = [
  { icon: "📍", label: "نشانی", value: "تهران، خیابان ولیعصر، بالاتر از میدان ونک، پلاک ۱۲۰" },
  { icon: "📞", label: "تلفن", value: "۰۲۱ - ۸۸۷۷۶۶۵۵" },
  { icon: "✉️", label: "ایمیل", value: "info@irangrains.ir" },
  { icon: "🕒", label: "ساعات کاری", value: "شنبه تا چهارشنبه، ۸ تا ۱۶" },
];

export default function Contact() {
  const [sent, setSent] = useState(false);

  return (
    <section id="contact" className="bg-grain-50 py-24 sm:py-28">
      <div className="mx-auto max-w-7xl px-4 sm:px-6">
        <div className="grid gap-10 lg:grid-cols-2">
          {/* Info */}
          <div>
            <span
              data-animate
              className="inline-flex items-center gap-2 rounded-full bg-white px-4 py-1.5 text-sm font-medium text-grain-700 shadow-sm"
            >
              تماس با ما
            </span>
            <h2
              data-animate
              data-animate-delay="0.05s"
              className="mt-4 text-3xl font-black text-grain-950 sm:text-4xl"
            >
              آماده‌ی پاسخگویی به شما هستیم
            </h2>
            <p
              data-animate
              data-animate-delay="0.1s"
              className="mt-4 leading-8 text-grain-600"
            >
              برای پرسش، پیشنهاد یا درخواست عضویت با ما در ارتباط باشید. کارشناسان
              ما در کوتاه‌ترین زمان پاسخگو خواهند بود.
            </p>

            <div className="mt-8 grid gap-4 sm:grid-cols-2">
              {INFO.map((item, i) => (
                <div
                  key={item.label}
                  data-animate
                  data-animate-delay={`${0.1 + i * 0.06}s`}
                  className="flex items-start gap-3 rounded-2xl bg-white p-4 shadow-sm ring-1 ring-grain-900/5"
                >
                  <span className="grid h-11 w-11 shrink-0 place-items-center rounded-xl bg-grain-100 text-xl">
                    {item.icon}
                  </span>
                  <div className="leading-tight">
                    <div className="text-xs text-grain-500">{item.label}</div>
                    <div className="mt-1 text-sm font-medium text-grain-800">
                      {item.value}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Form */}
          <div
            data-animate
            className="rounded-[2rem] bg-white p-7 shadow-xl shadow-grain-900/5 ring-1 ring-grain-900/5 sm:p-9"
          >
            {sent ? (
              <div className="flex h-full flex-col items-center justify-center py-12 text-center">
                <span className="grid h-16 w-16 place-items-center rounded-full bg-grain-100 text-3xl">
                  ✅
                </span>
                <h3 className="mt-4 text-xl font-bold text-grain-950">
                  پیام شما ثبت شد!
                </h3>
                <p className="mt-2 text-sm text-grain-600">
                  از تماس شما سپاسگزاریم. به‌زودی با شما تماس خواهیم گرفت.
                </p>
                <button
                  onClick={() => setSent(false)}
                  className="mt-6 rounded-full bg-grain-800 px-6 py-2.5 text-sm font-bold text-white transition-colors hover:bg-grain-900"
                >
                  ارسال پیام جدید
                </button>
              </div>
            ) : (
              <form
                onSubmit={(e) => {
                  e.preventDefault();
                  setSent(true);
                }}
                className="space-y-4"
              >
                <div className="grid gap-4 sm:grid-cols-2">
                  <Field label="نام و نام خانوادگی">
                    <input
                      required
                      type="text"
                      placeholder="مثلاً علی رضایی"
                      className="input"
                    />
                  </Field>
                  <Field label="نام شرکت / سازمان">
                    <input
                      type="text"
                      placeholder="اختیاری"
                      className="input"
                    />
                  </Field>
                </div>
                <div className="grid gap-4 sm:grid-cols-2">
                  <Field label="شماره تماس">
                    <input
                      required
                      type="tel"
                      inputMode="tel"
                      placeholder="۰۹۱۲۳۴۵۶۷۸۹"
                      className="input"
                    />
                  </Field>
                  <Field label="ایمیل">
                    <input
                      type="email"
                      placeholder="you@email.com"
                      dir="ltr"
                      className="input text-right"
                    />
                  </Field>
                </div>
                <Field label="موضوع">
                  <select className="input" defaultValue="">
                    <option value="" disabled>
                      یک گزینه انتخاب کنید…
                    </option>
                    <option>درخواست عضویت</option>
                    <option>دریافت بخشنامه‌ها</option>
                    <option>مشاوره‌ی تخصصی</option>
                    <option>سایر موارد</option>
                  </select>
                </Field>
                <Field label="پیام شما">
                  <textarea
                    rows={4}
                    placeholder="متن پیام خود را بنویسید…"
                    className="input resize-none"
                  />
                </Field>
                <button
                  type="submit"
                  className="w-full rounded-full bg-gold-400 px-6 py-3.5 font-bold text-grain-950 shadow-lg shadow-gold-500/20 transition-colors hover:bg-gold-500"
                >
                  ارسال درخواست
                </button>
              </form>
            )}
          </div>
        </div>
      </div>
    </section>
  );
}

function Field({
  label,
  children,
}: {
  label: string;
  children: ReactNode;
}) {
  return (
    <label className="block">
      <span className="mb-1.5 block text-sm font-medium text-grain-700">
        {label}
      </span>
      {children}
    </label>
  );
}
