const LINKS = {
  "دسترسی سریع": [
    { label: "خانه", href: "#home" },
    { label: "درباره ما", href: "#about" },
    { label: "رویدادها", href: "#events" },
    { label: "تماس با ما", href: "#contact" },
  ],
  "خدمات انجمن": [
    { label: "بخشنامه‌ها", href: "#services" },
    { label: "قیمت‌های مصوب", href: "#prices" },
    { label: "شرایط عضویت", href: "#members" },
    { label: "مشاوره‌ی تخصصی", href: "#services" },
  ],
};

const SOCIAL = [
  { icon: "📱", label: "تلگرام" },
  { icon: "📷", label: "اینستاگرام" },
  { icon: "▶️", label: "آپارات" },
  { icon: "✉️", label: "ایمیل" },
];

export default function Footer() {
  return (
    <footer className="bg-grain-950 text-white">
      <div className="mx-auto max-w-7xl px-4 py-16 sm:px-6">
        <div className="grid gap-10 lg:grid-cols-4">
          {/* Brand */}
          <div className="lg:col-span-1">
            <div className="flex items-center gap-2">
              <span className="grid h-11 w-11 place-items-center rounded-2xl bg-gradient-to-br from-grain-600 to-grain-800 text-2xl">
                🌾
              </span>
              <div className="leading-tight">
                <div className="text-lg font-extrabold">انجمن غلات ایران</div>
                <div className="text-[11px] text-gold-200">
                  مرجع تخصصی صنعت غلات
                </div>
              </div>
            </div>
            <p className="mt-5 text-sm leading-7 text-white/60">
              انجمن غلات ایران با هدف توسعه‌ی پایدار صنعت و دفاع از حقوق اعضا
              فعالیت می‌کند.
            </p>
            <div className="mt-5 flex gap-2">
              {SOCIAL.map((s) => (
                <a
                  key={s.label}
                  href="#contact"
                  aria-label={s.label}
                  className="grid h-10 w-10 place-items-center rounded-xl bg-white/5 text-lg ring-1 ring-white/10 transition-colors hover:bg-gold-400 hover:text-grain-950"
                >
                  {s.icon}
                </a>
              ))}
            </div>
          </div>

          {/* Link columns */}
          {Object.entries(LINKS).map(([title, items]) => (
            <div key={title}>
              <h4 className="font-bold text-gold-300">{title}</h4>
              <ul className="mt-4 space-y-3">
                {items.map((l) => (
                  <li key={l.label}>
                    <a
                      href={l.href}
                      className="text-sm text-white/60 transition-colors hover:text-gold-300"
                    >
                      {l.label}
                    </a>
                  </li>
                ))}
              </ul>
            </div>
          ))}

          {/* Newsletter */}
          <div>
            <h4 className="font-bold text-gold-300">خبرنامه</h4>
            <p className="mt-4 text-sm text-white/60">
              برای دریافت آخرین بخشنامه‌ها و رویدادها عضو خبرنامه شوید.
            </p>
            <form
              onSubmit={(e) => e.preventDefault()}
              className="mt-4 flex overflow-hidden rounded-full bg-white/5 p-1 ring-1 ring-white/10"
            >
              <input
                type="email"
                placeholder="ایمیل شما"
                dir="ltr"
                className="w-full bg-transparent px-4 text-sm text-white placeholder:text-white/40 focus:outline-none"
              />
              <button
                type="submit"
                className="shrink-0 rounded-full bg-gold-400 px-5 py-2.5 text-sm font-bold text-grain-950 transition-colors hover:bg-gold-300"
              >
                عضویت
              </button>
            </form>
          </div>
        </div>

        <div className="mt-12 flex flex-col items-center justify-between gap-4 border-t border-white/10 pt-6 text-sm text-white/50 sm:flex-row">
          <p>© ۱۴۰۳ انجمن غلات ایران — تمامی حقوق محفوظ است.</p>
          <div className="flex gap-5">
            <a href="#" className="transition-colors hover:text-gold-300">
              حریم خصوصی
            </a>
            <a href="#" className="transition-colors hover:text-gold-300">
              قوانین و مقررات
            </a>
          </div>
        </div>
      </div>
    </footer>
  );
}
