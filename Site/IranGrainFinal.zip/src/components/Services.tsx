const SERVICES = [
  {
    icon: "📜",
    title: "بخشنامه‌ها و اطلاع‌رسانی",
    desc: "انتشار سریع بخشنامه‌های دولتی، قیمنت‌های مصوب و تغییرات مقرراتی به اعضا.",
  },
  {
    icon: "💬",
    title: "مشاوره‌ی تخصصی",
    desc: "ارائه‌ی راهکار فنی و حقوقی در حوزه‌ی واردات، تولید، بازرگانی و انبارداری غلات.",
  },
  {
    icon: "🎤",
    title: "همایش‌ها و رویدادها",
    desc: "برگزاری نشست‌های تخصصی، نمایشگاه «ایران گرین» و کارگاه‌های آموزشی.",
  },
  {
    icon: "🏛️",
    title: "نمایندگی صنعت",
    desc: "دفاع از منافع اعضا و حضور مؤثر در کمیته‌ها و شوراهای تصمیم‌گیری کشوری.",
  },
  {
    icon: "🔬",
    title: "استاندارد و آزمایش",
    desc: "همکاری با آزمایشگاه‌های مرجع برای کنترل کیفیت و انطباق با استانداردها.",
  },
  {
    icon: "🤝",
    title: "حمایت از تولیدکنندگان",
    desc: "تسهیل ارتباط میان کشاورزان، واردکنندگان، صاحبان صنایع و نهادهای حمایتی.",
  },
];

export default function Services() {
  return (
    <section id="services" className="bg-grain-50 py-24 sm:py-28">
      <div className="mx-auto max-w-7xl px-4 sm:px-6">
        <div className="mx-auto max-w-2xl text-center">
          <span
            data-animate
            className="inline-flex items-center gap-2 rounded-full bg-white px-4 py-1.5 text-sm font-medium text-grain-700 shadow-sm"
          >
            بخشنامه‌ها و خدمات انجمن
          </span>
          <h2
            data-animate
            data-animate-delay="0.05s"
            className="mt-4 text-3xl font-black text-grain-950 sm:text-4xl"
          >
            چه کاری برای شما انجام می‌دهیم؟
          </h2>
          <p
            data-animate
            data-animate-delay="0.1s"
            className="mt-4 leading-8 text-grain-600"
          >
            مجموعه‌ای از خدمات تخصصی برای پوشش کامل نیازهای صنعت غلات؛ از
            اطلاع‌رسانی و مشاوره تا حمایت و استانداردسازی.
          </p>
        </div>

        <div className="mt-14 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {SERVICES.map((s, i) => (
            <article
              key={s.title}
              data-animate
              data-animate-delay={`${(i % 3) * 0.08}s`}
              className="group relative overflow-hidden rounded-3xl bg-white p-7 shadow-sm ring-1 ring-grain-900/5 transition-all duration-300 hover:-translate-y-1.5 hover:shadow-xl hover:shadow-grain-900/10"
            >
              <div className="absolute -left-10 -top-10 h-28 w-28 rounded-full bg-grain-100 transition-transform duration-500 group-hover:scale-150" />
              <div className="relative">
                <span className="grid h-14 w-14 place-items-center rounded-2xl bg-grain-900 text-2xl transition-transform duration-300 group-hover:scale-110">
                  {s.icon}
                </span>
                <h3 className="mt-5 text-lg font-bold text-grain-950">
                  {s.title}
                </h3>
                <p className="mt-2 text-sm leading-7 text-grain-600">
                  {s.desc}
                </p>
                <a
                  href="#contact"
                  className="mt-4 inline-flex items-center gap-1 text-sm font-bold text-grain-600 transition-colors group-hover:text-gold-600"
                >
                  اطلاعات بیشتر <span>←</span>
                </a>
              </div>
            </article>
          ))}
        </div>
      </div>
    </section>
  );
}
