import aboutImg from "../../public/images/about-silo.jpg";

const HIGHLIGHTS = [
  "نماینده‌ی رسمی صنعت غلات در نهادهای قانون‌گذار",
  "بخشنامه‌ها و قیمنت‌های مصوب را به‌موقع دریافت کنید",
  "دسترسی به شبکه‌ی تخصصی کارشناسان و تولیدکنندگان",
  "پشتیبانی فنی در حوزه‌ی استاندارد و آزمایش",
];

export default function About() {
  return (
    <section id="about" className="relative overflow-hidden py-24 sm:py-28">
      <div className="mx-auto grid max-w-7xl items-center gap-14 px-4 sm:px-6 lg:grid-cols-2">
        {/* Image */}
        <div data-animate className="relative">
          <div className="absolute -right-6 -top-6 h-40 w-40 rounded-3xl bg-gold-200/60 blur-2xl" />
          <div className="relative overflow-hidden rounded-[2rem] shadow-2xl shadow-grain-900/20 ring-1 ring-grain-900/5">
            <img
              src={aboutImg}
              alt="سیلوهای غلات و انبارهای صنعتی"
              className="aspect-[4/3] w-full object-cover"
            />
          </div>
          {/* Floating badge */}
          <div className="absolute -bottom-6 right-8 flex items-center gap-3 rounded-2xl bg-white p-4 shadow-xl shadow-grain-900/10 ring-1 ring-grain-900/5">
            <span className="grid h-12 w-12 place-items-center rounded-xl bg-grain-100 text-2xl">
              🛡️
            </span>
            <div className="leading-tight">
              <div className="text-sm font-bold text-grain-900">
                امنیت غذایی
              </div>
              <div className="text-xs text-grain-600">پایدار و ملی</div>
            </div>
          </div>
        </div>

        {/* Text */}
        <div>
          <span
            data-animate
            className="inline-flex items-center gap-2 rounded-full bg-grain-100 px-4 py-1.5 text-sm font-medium text-grain-700"
          >
            درباره‌ی انجمن غلات ایران
          </span>
          <h2
            data-animate
            data-animate-delay="0.05s"
            className="mt-4 text-3xl font-black leading-tight text-grain-950 sm:text-4xl"
          >
            مرجع معتبر صنعت <span className="text-grain-600">غلات</span> و
            دانه‌های روغنی کشور
          </h2>
          <p
            data-animate
            data-animate-delay="0.1s"
            className="mt-5 leading-8 text-grain-700"
          >
            انجمن غلات ایران با هدف توسعه‌ی پایدار صنعت و دفاع از حقوق اعضا
            فعالیت می‌کند. ما با ایجاد ارتباط سازنده میان بخش خصوصی و نهادهای
            دولتی، تلاش می‌کنیم تا شفافیت، استاندارد و رشد همه‌جانبه را در زنجیره‌ی
            ارزش غلات تضمین کنیم.
          </p>

          <ul className="mt-7 grid gap-3 sm:grid-cols-2">
            {HIGHLIGHTS.map((h, i) => (
              <li
                key={h}
                data-animate
                data-animate-delay={`${0.15 + i * 0.07}s`}
                className="flex items-start gap-3 rounded-2xl bg-white p-3.5 shadow-sm ring-1 ring-grain-900/5"
              >
                <span className="mt-0.5 grid h-6 w-6 shrink-0 place-items-center rounded-full bg-grain-600 text-xs text-white">
                  ✓
                </span>
                <span className="text-sm text-grain-700">{h}</span>
              </li>
            ))}
          </ul>

          <a
            href="#services"
            data-animate
            data-animate-delay="0.5s"
            className="mt-8 inline-flex items-center gap-2 rounded-full bg-grain-800 px-7 py-3.5 font-bold text-white transition-colors hover:bg-grain-900"
          >
            مشاهده‌ی اساسنامه و خدمات
          </a>
        </div>
      </div>
    </section>
  );
}
